import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collections;
import java.util.List;

import neuralnet.*;
import neuralnet.evo.*;

class RCFitness implements FitnessArbiter {
	BattleRunner br;

	public RCFitness() {
		br = new BattleRunner();
	}

	@Override
	public double fitness(NeuralNetwork nn) {
		try {
			PrintStream s = new PrintStream(new File(
					"/home/max/robocode/robots/MR/roboSpec"));
			double[] weights = nn.getWeights();
			int[] layers = nn.getLayers().clone();
			s.println(layers.length);
			for (int i = 0; i < layers.length; ++i)
				s.println(layers[i]);
			for (int i = 0; i < weights.length; ++i)
				s.println(weights[i]);
			s.flush();
			s.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return br.runBattle(nn).getScore();
	}
}

public class Main {
	public static void main(String[] args) {
		NeuralNetwork nn = new BasicNN(new int[] { 3, 7, 3, 4 });
		NeuroEvolver ne = new NeuroEvolver(nn, new RCFitness(), 32, 3);
		ne.trunkRatio = 0.3f;
		List<Genome> best = null;
		for (int i = 0; i < 200; ++i) {
			ne.evolveStep();
			best = ne.getBest();
			Collections.sort(best);
			System.out.println(i + " : " + (best.get(0).getFitness()));
		}
		double[] winner = best.get(0).getWeights();
		for(int i = 0; i < winner.length; ++i)
			System.out.println(winner[i]);

	}

}
