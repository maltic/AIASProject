package neuralnet.evo;

import neuralnet.NeuralNetwork;

public interface FitnessArbiter {
	double fitness(NeuralNetwork nn);
}
