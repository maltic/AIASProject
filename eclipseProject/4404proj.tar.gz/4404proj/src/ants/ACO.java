package ants;

import java.util.*;

public class ACO {
	protected int numAnts;
	
	protected static class Solution {
		
	}
	
	public ACO(int ants) {
		this.numAnts = ants;
	}
	
	protected ArrayList<ArrayList<Solution>> buildAntSolutions() {
		return null;
	}
	
	protected void updatePheromone() {
		;
	}
}
