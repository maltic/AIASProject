package MR;

import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

import neuralnet.BasicNN;
import neuralnet.NeuralNetwork;
import robocode.*;

public class MaxRobot extends AdvancedRobot {
	private NeuralNetwork nn;

	public void run() {
		try {
			FileReader fr = new FileReader(
					"/home/max/robocode/robots/MR/roboSpec");
			Scanner sc = new Scanner(fr);
			int nLayers = sc.nextInt();
			int[] layers = new int[nLayers];
			for (int i = 0; i < nLayers; ++i)
				layers[i] = sc.nextInt();
			nn = new BasicNN(layers);
			double[] weights = new double[nn.getNumWeights()];
			for (int i = 0; i < weights.length; ++i)
				weights[i] = sc.nextDouble();
			nn.setWeights(weights);
			sc.close();
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		while (true) {
			double[] input = new double[3];
			input[0] = this.getX() - this.getBattleFieldWidth() / 2;
			input[1] = this.getY() - this.getBattleFieldHeight() / 2;
			input[2] = this.getHeading() - 180;
			double[] out = nn.feedForward(input);
			double fb = 0.0;
			double lr = 0.0;
			if (out[0] > 0.01)
				fb += 10.0;
			else
				fb -= 10.0;

			if (out[1] > 0.01)
				lr += 10.0;
			else
				lr -= 10.0;

			if (out[2] > 0.01)
				fb += 10.0;
			else
				fb -= 10.0;

			if (out[3] > 0.01)
				lr += 10.0;
			else
				lr -= 10.0;

			this.setAhead(fb);
			this.setTurnLeft(lr);
			this.execute();
		}
	}

	public void onScannedRobot(ScannedRobotEvent e) {
		this.setFire(1.0);
	}

}
